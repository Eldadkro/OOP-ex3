package circuits;

public class CircuitException extends Exception {
	
}
